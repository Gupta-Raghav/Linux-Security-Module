#include <linux/lsm_hooks.h>
#include <linux/sysctl.h>
#include <linux/ptrace.h>
#include <linux/prctl.h>
#include <linux/ratelimit.h>
#include <linux/workqueue.h>
#include <linux/string_helpers.h>
#include <linux/task_work.h>
#include <linux/sched.h>
#include <linux/spinlock.h>


int osslsm_settime(const struct timespec64 *ts, const struct timezone *tz)
{


	struct timespec64 now;

	//if the ts is set to null or the user has tried to pass a null value to set time; Effort to stop the kernel to go into panic mode.
	if (!ts) {
		pr_info("OSS-LSM: Attempt to set null time.\n");
		return -EFAULT;
	}
	
	
	getnstimeofday64(&now);

	// Condition to check if the new time is before the current time. 
	// We return -EPERM to deny.
	if (timespec64_compare(ts, &now) < 0) {
		pr_info("OSS-LSM: rejecting time change in the past\n");		
		return -EPERM;
				
	}
	// Everything is okay, return 0 to grant permission.
	pr_info("OSS-LSM: Granting permission for changing the time\n");
	return 0;
}

static struct security_hook_list osslsm_hooks[] __lsm_ro_after_init = {
    //LSM_HOOK_INIT(ptrace_access_check, osslsm_ptrace_access_check),
    //LSM_HOOK_INIT(ptrace_traceme, osslsm_ptrace_traceme),
    LSM_HOOK_INIT(settime, osslsm_settime),
   // LSM_HOOK_INIT(task_prctl, osslsm_task_prctl),
    //LSM_HOOK_INIT(task_free, osslsm_task_free),
};

void __init osslsm_add_hooks(void)
{
    pr_info("osslsm: becoming mindful.\n");
    security_add_hooks(osslsm_hooks, ARRAY_SIZE(osslsm_hooks), "osslsm");
    //osslsm_init_sysctl();
}




//EXPORT_SYMBOL(osslsm_add_hooks);


